# Anchor

> Personalised memory games and a gentle AI assistant for people with early-stage dementia.

A senior-friendly web app that turns a person's own memories into gentle cognitive games. A caregiver adds photos, names and stories; the app builds activities from them; and a voice-enabled assistant (Mo) offers hints, easier questions or a calming break when it notices the person struggling. Built as an HCI course project by Nehal Abbott & Sonu, following high-contrast, low-pressure, non-scored design principles. The visual language follows the Lab 5 wireframes.

**Status: work in progress. Part 2 of 3 (personalised games + a living Memory Garden) complete.**

> Anchor gives behavioural estimates to guide the assistant, never a diagnosis. It is not a medical device.

## Run it

Run these from the folder that contains `package.json` and `src/`.

Requires **Node 18+** (tested on Node 22).

```bash
npm install
npm run dev          # http://localhost:5173
```

Open it on a phone-sized window (or DevTools device mode). On desktop it renders as a centred phone column.

Other commands:

```bash
npm test             # 64 tests: assistant logic, games, pond simulation, shell + toolbar behaviour
npm run typecheck
npm run build && npm run preview
npm run server       # optional: Part 3 API stub on :8787 (not needed yet)
```

## What's built so far

| Area | Files |
|---|---|
| App shell (content, persistent assistant toolbar, bottom nav) | `src/components/Layout.tsx`, `BottomNav.tsx` |
| **Assistant toolbar** (purple "Talk to Assistant" pill on every screen; pulses on its own after a quiet stretch) | `src/components/AssistantBar.tsx` |
| **Assistant panel** (chat, voice in, spoken replies, Clue / Easier / Break quick actions, safety notice) | `src/components/AssistantPanel.tsx` |
| **Proactive check-ins**: if the person goes quiet anywhere in the app, Mo first pulses the toolbar, then opens on its own with a concrete hint drawn from their memories | `src/assistant/useInactivityNudge.ts` |
| Pluggable assistant brain — answers "who am I" / "what am I doing" from the caregiver-entered profile, reassures without diagnosing, offline rules now, remote LLM in Part 3 | `src/assistant/brain.ts` |
| Voice input + text-to-speech (Web Speech API) | `src/assistant/speech.ts` |
| Caregiver memory profile (name, relationship, story, personal details) | `src/pages/Memories.tsx`, `src/store/useApp.ts` |
| Four games: Familiar Faces, Memory Match, Story Recall, Memory Sequence — non-scored, forgiving | `src/pages/Activity.tsx`, `src/games/*` |
| **Living Memory Garden**: a koi pond that swims calmly after right answers and darts faster and more erratically after wrong ones, the way startled fish actually move, plus the existing flower/rain garden that reflects how a session felt overall | `src/components/PondScene.tsx`, `src/games/pondMood.ts`, `src/games/pondSim.ts`, `src/pages/Garden.tsx` |
| State store (persisted to localStorage) | `src/store/useApp.ts` |
| Design tokens (mint/teal palette, 56px+ tap targets, AAA-contrast text) | `tailwind.config.js`, `src/styles/index.css` |
| Part 3 API stub | `server/index.js` |

## How the pond works

Each right or wrong answer is logged with the game (`src/pages/Activity.tsx`). `pondMoodFromEvents` (`src/games/pondMood.ts`) turns the last few answers into a mood from -1 (recent mistakes) to +1 (recent successes), weighting the most recent answers more heavily so an old rough patch fades rather than lingering. `pondSim.ts` runs a small physics simulation — each fish steers gradually toward a wandering target rather than snapping between points — and mood scales the fish's speed and turning noise: calm and slow when things are going well, faster and more erratic when they aren't. It's purely a feel-good visual cue, never shown as a number or score, and it respects `prefers-reduced-motion`.

## Notes

- **Voice input** uses the browser's Web Speech API: works in Chrome/Edge/Safari, not Firefox. Typing always works as a fallback. It needs `localhost` or HTTPS and microphone permission.
- The assistant gives **wellbeing guidance only** and declines medical questions (per the Lab 4 ethics section). State estimates are behavioural, never diagnostic. "Who am I" answers only use facts a caregiver actually entered — Mo never invents personal details.
- Data lives in your browser's localStorage. Clear it via DevTools to reset. No backend or API key is needed yet.
- The assistant **logs interaction signals** (`help_request`, `speech_cue`, `response_submitted` with correctness) into the store. Part 3 consumes these for frustration/confusion estimation.

## Roadmap

**Part 3 — Adaptive loop**
Frustration/confusion state estimation (the five states from the Lab 4 report), Whisper transcription and LLM replies via `server/`, adaptive responses (simplify, calming activity, break), biweekly assessment, and privacy/consent. Switch `brain` to `RemoteBrain` in `src/assistant/brain.ts`.

## GitHub repo settings

**About:** Personalised memory games and a gentle AI assistant for people with early-stage dementia.

**Topics:** `dementia` `cognitive-training` `accessibility` `hci` `react` `typescript` `assistive-technology` `speech-recognition` `serious-games` `elderly-care`
